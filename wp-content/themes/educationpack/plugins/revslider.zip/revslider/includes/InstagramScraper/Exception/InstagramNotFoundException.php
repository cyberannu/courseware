<?php

namespace InstagramScraper\Exception;

class InstagramNotFoundException extends \Exception
{
}